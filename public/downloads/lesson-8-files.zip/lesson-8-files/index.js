// #### Imports
import * as scrawl from "https://unpkg.com/scrawl-canvas@8.9.10";

import * as frame from './simple-chart-frame.js';
import {api as barGraph} from './london-crime-stacked-bars.js';
import {api as lineGraph} from './london-crime-lines.js';


// #### Initial setup
scrawl.importDomImage('.crime');

const canvas = scrawl.library.canvas.mycanvas;
const namespace = 'Crimes';
const name = (item) => `${namespace}-${item}`;

// Accessibility
canvas.set({

    label: 'Crime statistics for London areas - from 1999 to 2017',
    description: 'Interactive graphic showing crimes recorded in various London areas, broken down into crime types. Data taken from https://data.london.gov.uk/dataset/recorded_crime_rates',
});


// #### Animation and reporting
scrawl.makeRender({
    name: name('animation'),
    target: canvas,
});


// #### User interaction
scrawl.addListener(
    'move', 
    () => canvas.cascadeEventAction('move'), 
    canvas.domElement 
);

scrawl.addNativeListener(
    'touchstart', 
    () => canvas.cascadeEventAction('move'), 
    canvas.domElement 
);

// For this demo we will suppress touchmove functionality over the canvas
scrawl.addNativeListener('touchmove', (e) => {

    e.preventDefault();
    e.returnValue = false;

}, canvas.domElement);


// Infographic state
let currentGraphType = 'bars',
    currentArea = 'Hackney',
    currentCategory = 'Burglary';

const crimeCategoryInput = document.querySelector('#crime-categories');
crimeCategoryInput.value = 'Burglary';
crimeCategoryInput.setAttribute('disabled', '');

scrawl.addNativeListener(['input', 'change'], function (e) {

    if (e && e.target) {

        e.preventDefault();
        e.stopPropagation();

        const target = e.target.id,
            value = e.target.value;

        switch (target) {

            case 'areas' :

                if (value !== currentArea) {

                    currentArea = value;

                    if (currentGraphType === 'bars') {

                        barGraph.kill();

                        // We need to delay the rebuild to the next Display cycle
                        // + SC library purges are batched to run once per RAF
                        // + We can't rebuild until after the library is purged
                        setTimeout(() => barGraph.build({
                            namespace: name('bars'), 
                            dataSource: `./crimes-in-${currentArea.toLowerCase()}.json`,
                            canvas,
                            scrawl,
                        }), 0);
                    }
                    else if (currentGraphType === 'lines') {

                        lineGraph.kill();

                        // Again, we delay the rebuild to the next Display cycle
                        setTimeout(() => lineGraph.build({
                            namespace: name('lines'), 
                            dataSource: `./crimes-in-${currentArea.toLowerCase()}.json`,
                            category: currentCategory,
                            canvas,
                            scrawl,
                        }), 0);
                    }
                }
                break;

            case 'graph-types' :

                if (value !== currentGraphType) {

                    currentGraphType = value;

                    if (currentGraphType === 'bars') {

                        lineGraph.kill();

                        barGraph.build({
                            namespace: name('bars'), 
                            dataSource: `./crimes-in-${currentArea.toLowerCase()}.json`,
                            canvas,
                            scrawl,
                        });

                        crimeCategoryInput.setAttribute('disabled', '');
                    }
                    else if (currentGraphType === 'lines') {

                        barGraph.kill();

                        lineGraph.build({
                            namespace: name('lines'), 
                            dataSource: `./crimes-in-${currentArea.toLowerCase()}.json`,
                            category: currentCategory,
                            canvas,
                            scrawl,
                        });

                        crimeCategoryInput.removeAttribute('disabled');
                    }
                }
                break;

            case 'crime-categories' :

                if (currentGraphType === 'lines' && value !== currentCategory) {

                    currentCategory = value;

                    lineGraph.update({
                        namespace: name('lines'),
                        category: currentCategory,
                        canvas, 
                        scrawl,
                    });
                }
                break;
        }
    }
}, '.control-item');


// #### Build out initial graphic
frame.build({
    namespace: name('frame'),
    backgroundImage: 'Hackney',
    canvas,
    scrawl,
});

barGraph.build({
    namespace: name('bars'), 
    dataSource: './crimes-in-hackney.json',
    canvas,
    scrawl,
});
